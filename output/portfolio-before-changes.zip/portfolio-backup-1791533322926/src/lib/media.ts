/** Committed artwork used wherever a section has no project screenshot. */
export const ART = {
  hero: "/images/art/hero.webp",
  heroMobile: "/images/art/hero-mobile.webp",
  portrait: "/images/art/silk-portrait.webp",
  pill: "/images/art/silk-pill.webp",
  mission: "/images/art/mission.webp",
  benefits: "/images/art/benefits.webp",
  footer: "/images/art/footer.webp",
  dark: ["/images/art/dark-1.webp", "/images/art/dark-2.webp", "/images/art/dark-3.webp"],
  light: ["/images/art/light-1.webp", "/images/art/light-2.webp", "/images/art/light-3.webp"],
};

/** Real project screenshot: `work("mechaura", 2)` → /images/work/mechaura-mockup-2.webp */
export const work = (slug: string, n = 1) => `/images/work/${slug}-mockup-${n}.webp`;
