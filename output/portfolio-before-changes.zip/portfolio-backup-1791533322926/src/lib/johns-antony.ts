import { work } from "@/lib/media";

/**
 * Personal portfolio content for Johns Antony. Projects without a screenshot
 * use placeholder art until real imagery is added.
 */

export const PROFILE = {
  name: "Johns Antony",
  title: "Digital & E-commerce Specialist | Systems & IT Administrator",
  positioning: "Building, improving and operating the digital systems behind modern commerce.",
  heroDescription:
    "I build and manage digital commerce experiences across Shopify, custom websites, payments, analytics, automation and IT systems. My work combines hands-on development with technical operations, quality assurance and business support — from storefront interfaces and custom Shopify functionality to payment platforms, domains, infrastructure and digital accounts.",
  supporting: ["Shopify", "Web Development", "E-commerce", "Payments", "Automation", "QA", "IT Systems"],
  location: "Based in Dubai, UAE",
  phone: "+971 58 810 2728",
  email: "johnsantonyjo@gmail.com",
  linkedin: "https://www.linkedin.com/in/johns-antony",
  seoTitle: "Johns Antony | Digital & E-commerce Specialist in Dubai",
  seoDescription:
    "Johns Antony is a Digital & E-commerce Specialist and Systems & IT Administrator based in Dubai, specialising in Shopify development, web delivery, payments, analytics, automation, QA and IT systems.",
};

export const ABOUT = {
  heading: "I work across the technology behind digital commerce.",
  short:
    "A digital commerce specialist with a systems mindset. I work across Shopify, web development, payments, analytics, automation, QA and IT infrastructure, helping businesses build and maintain digital platforms that are practical, reliable and ready for everyday operations.",
  paragraphs: [
    "I'm Johns Antony, a Digital & E-commerce Specialist and IT professional based in Dubai, UAE, with 5+ years of experience across Shopify e-commerce, web delivery, system administration, network infrastructure and software quality assurance.",
    "My current work brings together several areas that are normally handled by separate teams. I manage and develop Shopify storefronts, implement custom Liquid, CSS and JavaScript functionality, support payment gateways and retail POS systems, manage domains and SSL certificates, maintain digital accounts, support analytics and tracking, and work with teams across IT, Finance, Retail, HR and Customer Care.",
    "I enjoy working close to the actual business problem. That means understanding what a customer needs, what a store team needs, what an internal team needs, and then translating those requirements into a reliable technical solution.",
    "My background in QA and systems administration also shapes the way I build. I don't look only at whether something looks correct — I consider functionality, performance, access, reliability, tracking, deployment and what can happen after launch.",
  ],
};

export const SERVICES = [
  { title: "Shopify & E-commerce", text: "I develop and maintain Shopify storefronts, from theme sections and Liquid customisation to product pages, collections, catalogue management, shipping rules, checkout-related functionality and third-party integrations.", tags: ["Shopify themes", "Custom Liquid", "Sections & blocks", "Product feeds"] },
  { title: "Web Development & Delivery", text: "I translate approved designs and business requirements into functional websites and digital experiences, working across Shopify and non-Shopify environments.", tags: ["Figma-to-web", "Responsive front-end", "API integrations", "Deployment"] },
  { title: "Payments & Retail Technology", text: "I support the technical layer connecting online commerce with payment and retail operations.", tags: ["Payment gateways", "Tabby & Tamara", "Payment links", "POS"] },
  { title: "Analytics, Tracking & Digital Platforms", text: "I implement and maintain the technical foundations needed to measure digital activity and keep business platforms connected.", tags: ["GA4", "GTM & dataLayer", "Merchant Center", "Technical SEO"] },
  { title: "QA & Release Quality", text: "My software testing background gives me a structured approach to releases and troubleshooting.", tags: ["Regression testing", "UAT", "Selenium", "Appium"] },
  { title: "IT Systems & Infrastructure", text: "I also work across the systems supporting business operations, including networks, endpoints, security devices and infrastructure.", tags: ["Windows & Linux", "DNS / DHCP / VPN", "Firewalls", "CCTV & access control"] },
  { title: "Automation", text: "I build practical automation workflows that reduce repetitive work and connect different business systems.", tags: ["n8n", "Google Sheets", "API workflows", "CRM pipelines"] },
];

export const SNAPSHOT = [
  { value: "5+ Years", label: "Professional experience" },
  { value: "9+", label: "E-commerce / digital brands supported" },
  { value: "30+", label: "Domains & SSL certificates managed" },
  { value: "30+", label: "Digital accounts administered" },
  { value: "99%+", label: "Infrastructure uptime experience" },
  { value: "40%", label: "Reported QA automation coverage improvement" },
];

export const PROJECTS = [
  { title: "The House of Karji", labels: ["Shopify", "Custom Development"], description: "Shopify commerce, custom Liquid, collections, product feeds and operational improvements for a multi-location fragrance and lifestyle business.", image: work("house-of-karji") },
  { title: "Atelier Perfumery", labels: ["Shopify", "Analytics"], description: "Figma-to-Shopify rebuild with brand discovery, analytics, tracking, product feeds and custom commerce functionality.", image: work("atelier-perfumery") },
  { title: "Flower District", labels: ["E-commerce", "Delivery Technology"], description: "Flower e-commerce with location-based delivery, scheduled slots, WhatsApp support and local store landing pages.", image: work("flower-district") },
  { title: "Daima", labels: ["Shopify", "E-commerce"], description: "Shopify product-page and storefront optimisation focused on purchase functionality and responsive presentation.", image: work("daima") },
  { title: "Saleel Parfums", labels: ["Shopify", "E-commerce"], description: "Shopify storefront improvements across product-page functionality, wallet interactions and responsive UI.", image: work("saleel-parfums") },
  { title: "Touch of Oud", labels: ["Shopify", "E-commerce"], description: "Shopify development and ongoing storefront support for a fragrance e-commerce brand.", image: work("touch-of-oud") },
  { title: "Mechaura International", labels: ["B2B Website", "Automation"], description: "B2B industrial website and automated lead-generation ecosystem powered by n8n and connected data workflows.", url: "https://mechaurainternational.com", image: work("mechaura") },
  { title: "DuooNex", labels: ["Digital Agency", "Web Platform"], description: "Digital agency and e-commerce platform concept with responsive UI and administration capabilities.", image: work("jkr-international") },
  { title: "Pacifyr", labels: ["Mobile App", "Web Admin"], description: "Mobile application and connected web administration platform.", image: work("pacifyr") },
  { title: "ForWheels", labels: ["Mobile App", "Web Admin"], description: "Mobile application ecosystem with supporting web administration and QA.", image: work("rydge-studio") },
];

/** Independent product builds, captured from local builds with demonstration data. */
export const BUILDS = [
  { title: "Finora", slug: "finora", labels: ["Accounting", "Next.js"], description: "A UAE-focused accounting platform connecting sales, purchases, inventory, banking and ledger-based business reports." },
  { title: "The House of Karji — Custom Build", slug: "house-of-karji", labels: ["Commerce", "Next.js"], description: "A custom luxury fragrance storefront with editorial merchandising, a fragrance finder and a full commerce admin." },
  { title: "Nexora", slug: "nexora", labels: ["Help Desk", "Next.js"], description: "A shared workspace for support tickets, tasks, approvals and customer service, with organisation-scoped access and activity history." },
  { title: "Invitara", slug: "invitara", labels: ["Platform", "Node.js"], description: "Animated digital invitations with personalisation, guest replies, account-based publishing and event-date access rules." },
  { title: "CertGuard", slug: "certguard", labels: ["Domains & SSL", "Next.js"], description: "A domain and SSL control panel that verifies expiry dates against live sources, alerts before expiry and automates certificate renewal." },
  { title: "WorkFlow Hub", slug: "workflow-hub", labels: ["Operations", "Next.js"], description: "An internal tool that turns incoming emails into owned tasks, drafts professional replies and chases work until it is closed." },
];

export const ADDITIONAL_WORK = [
  { title: "Mechaura International", category: "B2B industrial website and lead-generation ecosystem", year: "Web", url: "https://mechaurainternational.com" },
  { title: "Blue Ocean Fashion", category: "WordPress-based website support and development", year: "Web" },
  { title: "Juvenis Paris", category: "Website maintenance and hosting support, including cPanel", year: "Web" },
];

export const EXPERIENCE = [
  { title: "Digital & E-commerce Specialist", category: "Maylaa International — Dubai, UAE", year: "Nov 2025 – Present" },
  { title: "Software QA Tester", category: "Ceino Technologies — Kozhikode, Kerala, India", year: "2023 – Nov 2025" },
  { title: "System Engineer", category: "Wiinnova Software Labs — Kerala, India", year: "Sep 2022 – May 2023" },
  { title: "System Administrator & IT Support Specialist", category: "Various Organisations — Kerala, India", year: "Jan 2021 – 2023" },
];

export const SKILLS = [
  { title: "E-commerce & CMS", text: "Shopify · Shopify Themes · Liquid · Collections · Product Feeds · Checkout · Custom Pixels · WordPress · Figma-to-Shopify" },
  { title: "Web", text: "HTML · CSS · JavaScript · Java · Responsive Development · Basic Full-Stack Development" },
  { title: "Marketing & Analytics", text: "Google Ads · TikTok Ads · GA4 · Google Tag Manager · Google Merchant Center · Google Business Profile · SEO" },
  { title: "Payments", text: "Payment Gateways · Payment Links · Tabby · Tamara · Network Payment Terminals · POS" },
  { title: "Hosting & Domains", text: "cPanel · DNS · Domains · SSL · Hosting · Deployment Support" },
  { title: "Automation", text: "n8n · Google Sheets · API-Based Workflows · Lead Generation · AI-Assisted Qualification" },
  { title: "Systems & Networking", text: "Windows Server/Desktop · Linux · Ubuntu · CentOS · TCP/IP · DNS · DHCP · VPN · Firewalls" },
  { title: "Security & Hardware", text: "CCTV · Biometrics · Access Control · PABX · POS Peripherals · Endpoint Security" },
  { title: "QA", text: "Selenium · Appium · Jira · Trello · Manual Testing · Regression Testing · Test Case Management" },
  { title: "Methods & Productivity", text: "Microsoft 365 · Google Workspace · Advanced Excel · Agile/Scrum · SDLC · STLC · ITIL" },
];

export const EDUCATION = [
  { title: "Bachelor of Engineering — Computer Science", category: "Vinayaka Mission's Research Foundation – University · CGPA 8.273 / 10", year: "2018 – 2022" },
  { title: "Languages", category: "English · Malayalam · Hindi", year: "" },
];

export const PROCESS = [
  { title: "Understand", text: "I start by understanding the business requirement, the users, the existing technology and the operational constraints." },
  { title: "Plan", text: "I break the requirement into practical technical components and identify dependencies, integrations and edge cases." },
  { title: "Build", text: "I implement the solution with a focus on clean interfaces, maintainability, responsiveness and real-world usability." },
  { title: "Test", text: "I validate functionality across devices and scenarios, using a QA mindset developed through professional testing experience." },
  { title: "Connect", text: "I make sure the digital experience works with the surrounding systems — payments, analytics, feeds, domains, accounts and business workflows." },
  { title: "Maintain", text: "After launch, I troubleshoot, improve, monitor and adapt the platform as business requirements change." },
];

export const APPROACH =
  "A digital product can look perfect and still fail operationally. My approach considers the complete system — design, development, functionality, tracking, payments, infrastructure, testing and operations — so I can work comfortably between business teams, designers, developers, finance teams, retail teams and IT operations.";

export const OFFER = [
  { title: "For\nBrands", text: "Shopify development, e-commerce optimisation, custom Shopify sections and integrations, and tracking connected to GA4, GTM, dataLayer and advertising ecosystems." },
  { title: "For\nBusinesses", text: "Corporate websites, business automation with n8n and connected APIs, and digital operations — domains, accounts, access, SSL, payment systems and platform requirements." },
  { title: "For Technology\nTeams", text: "Structured manual and automated testing for web and mobile releases, plus troubleshooting across platform, website, payment, network and system issues." },
];

export const CONTACT = {
  heading: "Have a project, platform or problem to solve?",
  text: "Whether you are building a new e-commerce experience, improving an existing Shopify store, connecting business systems, automating a workflow or solving a technical problem, I'm open to discussing the requirement.",
  closingHeading: "Let's build something useful.",
  closing:
    "Good technology should make business easier. If you have an e-commerce store that needs improvement, a website that needs to be built, a workflow that should be automated, or a technical problem that needs solving, let's talk about the requirement and find the most practical way forward.",
  footer: "Building practical digital experiences and the systems that keep them running.",
};
