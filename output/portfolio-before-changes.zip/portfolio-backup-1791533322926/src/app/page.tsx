import type { Metadata } from "next";

import { Footer } from "@/components/editorial/Footer";
import { Interactions } from "@/components/editorial/Interactions";
import { Nav } from "@/components/editorial/Nav";
import { Mail, Phone, Pin } from "@/components/editorial/icons";
import {
  AboutSection,
  Achievements,
  AwardsList,
  BenefitsSection,
  CallToAction,
  CardsGrid,
  ContactLines,
  Hero,
  PlaygroundSection,
  PortfolioSection,
  ServicesCarousel,
  SplitMission,
} from "@/components/editorial/sections";
import { SectionHead } from "@/components/editorial/ui";
import {
  ABOUT,
  ADDITIONAL_WORK,
  APPROACH,
  BUILDS,
  CONTACT,
  EDUCATION,
  EXPERIENCE,
  OFFER,
  PROCESS,
  PROFILE,
  PROJECTS,
  SERVICES,
  SKILLS,
  SNAPSHOT,
} from "@/lib/johns-antony";
import { ART, work } from "@/lib/media";

export const metadata: Metadata = {
  title: { absolute: PROFILE.seoTitle },
  description: PROFILE.seoDescription,
  alternates: { canonical: "/" },
  openGraph: {
    title: "Johns Antony — Digital & E-commerce Specialist",
    description: "Shopify, web development, payments, analytics, automation, QA and IT systems — building and supporting the technology behind modern commerce.",
    type: "profile",
  },
};

/** Placeholder artwork until real project screenshots are added. */
const art = (n: number) => [...ART.dark, ...ART.light][n % 6];
const pad = (n: number, width = 3) => `/${String(n).padStart(width, "0")}`;

export default function Home() {
  const year = new Date().getUTCFullYear();
  const mailto = `mailto:${PROFILE.email}`;

  return (
    <div className="rx" id="top">
      <a href="#main" className="rx-skip">Skip to content</a>
      <Interactions>
        <Nav
          overlay
          brand={PROFILE.name}
          location={PROFILE.location}
          items={[
            { label: "About", href: "#about" },
            { label: "Work", href: "#work" },
            { label: "Experience", href: "#experience" },
            { label: "Skills", href: "#skills" },
            { label: "Contact", href: "#contact" },
          ]}
          icon={{ href: "#contact", label: "Let's Work Together" }}
        />
        <main id="main">
          <Hero
            title={PROFILE.name}
            services={["Shopify & E-commerce", "Web & Payments", "Analytics & Automation", "QA & IT Systems"]}
            text={PROFILE.positioning}
            cta={{ label: "View My Work", href: "#work" }}
            captionLeft={`Digital & E-commerce Specialist / ©${year}`}
            image={ART.hero}
            imageMobile={ART.heroMobile}
          />

          <AboutSection
            body={`${ABOUT.heading} ${ABOUT.short}`}
            cta={{ label: "Let's Work Together", href: "#contact" }}
            images={[ART.portrait, ART.pill]}
            marquee={{ heading: "About Me", index: "/01" }}
          />

          <section className="section">
            <div className="container">
              <div className="grid-12 sm">
                <div className="span-full">
                  {ABOUT.paragraphs.map((p) => (
                    <div key={p.slice(0, 24)} className="mb-small"><p className="paragraph-medium no-indent" data-ix="lines">{p}</p></div>
                  ))}
                </div>
              </div>
            </div>
          </section>

          <section className="section shadow">
            <div className="container-fluid">
              <div className="mb-large">
                <SectionHead label="(Snapshot)" index="/02">
                  <h3 className="heading-medium" data-ix="lines">A hybrid technology profile</h3>
                </SectionHead>
              </div>
            </div>
            <Achievements items={SNAPSHOT.map((s, i) => ({ ...s, image: art(i) }))} />
          </section>

          <ServicesCarousel
            label="(What I Do)"
            index="/03"
            body="What I bring to a digital project — from storefront to systems."
            items={SERVICES.map((s, i) => ({ index: pad(i + 1), title: s.title, text: s.text, image: art(i), tags: s.tags }))}
          />

          <SplitMission
            label="(My Approach)"
            eyebrow={`${PROFILE.name}\n/ ©${year}`}
            words={["Build", "Connect", "Operate"]}
            text={APPROACH}
            index="/04"
            image={ART.mission}
            circle={{ href: "#work", text: "View my work · Selected projects · ", label: "View selected work" }}
          />

          <PortfolioSection
            label="(Selected Work)"
            index="/05"
            heading={`Selected Work\n©${year}`}
            projects={PROJECTS.map((p, i) => ({ title: p.title, href: p.url, image: p.image ?? art(i), alt: p.title, labels: p.labels, description: p.description }))}
            cta={{ body: "A selection of e-commerce, web, automation, mobile and digital technology projects spanning Shopify development, payment systems, analytics, business automation and technical operations.", label: "Start a Conversation", href: "#contact" }}
          />

          <PortfolioSection
            id="builds"
            label="(Product Builds)"
            index="/06"
            heading={"Independent builds"}
            projects={BUILDS.map((b) => ({ title: b.title, image: work(b.slug), alt: b.title, labels: b.labels, description: b.description }))}
          />

          <PlaygroundSection
            label="(Screens)"
            index="/07"
            heading="From the builds"
            images={[work("finora", 3), work("invitara"), work("house-of-karji", 2), work("mechaura", 2), work("nexora"), work("certguard", 2), work("workflow-hub", 2)].map((src) => ({ src }))}
          />

          <section className="section shadow" id="experience">
            <div className="container-fluid">
              <div className="mb-large">
                <SectionHead label="(Experience)" index="/08">
                  <h3 className="heading-medium" data-ix="lines">5+ years of practical technology experience</h3>
                </SectionHead>
              </div>
              <div className="mb-large"><AwardsList items={EXPERIENCE} /></div>
              <div className="mb-medium">
                <SectionHead label="(Additional Web Work)" />
              </div>
              <div className="mb-large"><AwardsList items={ADDITIONAL_WORK} /></div>
              <div className="mb-medium">
                <SectionHead label="(Education & Languages)" />
              </div>
              <AwardsList items={EDUCATION} />
            </div>
          </section>

          <section className="section" id="skills">
            <div className="container-fluid">
              <div className="mb-large">
                <SectionHead label="(Skills)" index="/09">
                  <h3 className="heading-medium" data-ix="lines">Technical capabilities</h3>
                </SectionHead>
              </div>
              <CardsGrid small items={SKILLS.map((s, i) => ({ number: pad(i + 1, 2), title: s.title, text: s.text }))} />
            </div>
          </section>

          <section className="section shadow">
            <div className="container-fluid">
              <div className="mb-large">
                <SectionHead label="(How I Work)" index="/10">
                  <h3 className="heading-medium" data-ix="lines">From requirement to reliable release.</h3>
                </SectionHead>
              </div>
              <CardsGrid parallax items={PROCESS.map((p, i) => ({ number: pad(i + 1, 2), title: p.title, text: p.text }))} />
            </div>
          </section>

          <BenefitsSection
            label="(Services)"
            index="/11"
            headingOne={"A developer who\nunderstands the\nbusiness"}
            headingTwo={"Around\nthe code"}
            items={OFFER.map((o, i) => ({ index: pad(i + 1), title: o.title, text: o.text, image: art(i + 3) }))}
          />

          <section className="section" id="contact">
            <div className="container-fluid">
              <div className="mb-large">
                <SectionHead label="(Contact)" index="/12">
                  <h3 className="heading-medium" data-ix="lines">{CONTACT.heading}</h3>
                </SectionHead>
              </div>
              <div className="mb-medium"><p className="paragraph-large" data-ix="lines"><span className="indent-medium" />{CONTACT.text}</p></div>
              <ContactLines
                items={[
                  { label: PROFILE.email, href: mailto, icon: <Mail />, index: "/001" },
                  { label: PROFILE.phone, href: `tel:${PROFILE.phone.replace(/[^\d+]/g, "")}`, icon: <Phone />, index: "/002" },
                  { label: "linkedin.com/in/johns-antony", href: PROFILE.linkedin, icon: <Pin />, index: "/003" },
                ]}
              />
            </div>
          </section>

          <CallToAction heading={CONTACT.closingHeading} index="/13" text={CONTACT.closing} cta={{ label: "Let's Work Together →", href: mailto }} />
        </main>
        <Footer
          lineOne="Johns"
          lineTwo="Antony"
          headline={CONTACT.footer}
          cta={{ label: "Start a Conversation", href: mailto }}
          socials={[
            { label: "Home", href: "#top" },
            { label: "About", href: "#about" },
            { label: "Work", href: "#work" },
            { label: "Experience", href: "#experience" },
            { label: "Skills", href: "#skills" },
            { label: "Contact", href: "#contact" },
            { label: "LinkedIn", href: PROFILE.linkedin },
          ]}
          badge={{ text: "Let's work together · Say hello · ", href: mailto, label: "Contact" }}
          credits={<><span>© Johns Antony. All rights reserved.</span><span>{PROFILE.title} · Dubai, UAE</span></>}
        />
      </Interactions>
    </div>
  );
}
