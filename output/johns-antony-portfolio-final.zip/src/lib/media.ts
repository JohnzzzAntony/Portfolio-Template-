/** Owner-supplied portraits, lossless WebP conversions. No face or body edits. */
export const ART = {
  hero: "/images/owner/portrait.webp",
  heroMobile: "/images/owner/portrait.webp",
  dubai: "/images/owner/dubai.webp",
  portrait: "/images/owner/casual.webp",
  pill: "/images/owner/portrait.webp",
  mission: "/images/owner/workspace.webp",
  benefits: "/images/owner/workspace.webp",
  footer: "/images/owner/motion.webp",
};
export const work = (slug: string, n = 1) => `/images/work/${slug}-mockup-${n}.webp`;
export const SERVICE_IMAGES = [ART.mission, work("invitara"), work("finora", 2), work("finora", 3), work("nexora", 2), work("certguard", 2), work("workflow-hub", 2)];
export const SNAPSHOT_IMAGES = [ART.hero, ART.portrait, work("certguard"), work("nexora"), ART.mission, work("workflow-hub")];
