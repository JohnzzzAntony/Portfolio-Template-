import type { Metadata } from "next";
import localFont from "next/font/local";

import "./globals.css";

// Overused Grotesk (SIL OFL 1.1, see fonts/OverusedGrotesk-OFL.txt), bundled locally.
const grotesk = localFont({
  src: "./fonts/overused-grotesk-vf.woff2",
  variable: "--font-grotesk",
  display: "swap",
  weight: "300 900",
});

export const metadata: Metadata = {
  title: { default: "Johns Antony", template: "%s" },
};

// Runs before first paint so scroll-revealed elements start hidden instead of flashing.
const markScripted = "document.documentElement.classList.add('js')";

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={grotesk.variable} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: markScripted }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
