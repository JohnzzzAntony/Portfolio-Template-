import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import products from "@/lib/product-details.json";
import { PROFILE } from "@/lib/johns-antony";

export function generateStaticParams() {
  return products.map(({ slug }) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const product = products.find(p => p.slug === slug);
  if (!product) notFound();
  return { title: `${product.name} — Johns Antony`, description: product.summary, openGraph: { images: [product.gallery[0].src] } };
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = products.find(p => p.slug === slug);
  if (!product) notFound();
  return (
    <main className="product-detail">
      <nav aria-label="Product navigation"><Link href="/">Johns Antony.</Link><Link href="/#work">All products ↗</Link></nav>
      <header>
        <p className="product-eyebrow">Independent product / {product.stack}</p>
        <h1>{product.name}</h1>
        <p className="product-summary">{product.summary}</p>
      </header>
      <figure className="product-detail-hero"><Image src={product.gallery[0].src} alt={product.gallery[0].alt} fill sizes="(max-width: 768px) 100vw, 90vw" preload /></figure>
      <section className="product-story" aria-labelledby="overview">
        <h2 id="overview">Built around real work.</h2>
        <div><p>{product.overview}</p><p className="product-note">Screenshots show the developed application with demonstration data.</p></div>
      </section>
      <section className="product-features" aria-labelledby="features"><h2 id="features">Inside the product</h2><ul>{product.features.map(feature => <li key={feature}>{feature}</li>)}</ul></section>
      <section className="product-gallery" aria-label={`${product.name} screenshots`}>
        {product.gallery.slice(1).map(image => <figure key={image.src}><div className="product-detail-hero"><Image src={image.src} alt={image.alt} fill sizes="(max-width: 768px) 100vw, 90vw" /></div><figcaption>{image.alt}</figcaption></figure>)}
      </section>
      <section className="product-story"><h2>Let’s build something useful.</h2><div><p>Interested in this product or a similar system?</p><a className="product-contact" href={`mailto:${PROFILE.email}?subject=${encodeURIComponent(`Enquiry about ${product.name}`)}`}>Discuss {product.name} ↗</a></div></section>
      <footer><Link href="/#work">← Back to all products</Link><span>© {new Date().getUTCFullYear()} Johns Antony</span></footer>
    </main>
  );
}
